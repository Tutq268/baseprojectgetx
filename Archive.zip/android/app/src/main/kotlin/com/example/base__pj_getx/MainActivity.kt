package com.example.base__pj_getx

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

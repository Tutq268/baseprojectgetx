import 'package:get/get.dart';

class MessageController extends GetxController {
  final String title = "Message controller";
}

import 'package:get/get.dart';

class AddController extends GetxController {
  final String title = "Add controller";
}
